<?php

  // Step 1: (12) Using either MySQLi or PDO
  //    Create a connection to your MySQL DB and store it in a variable named $conn
  // CREATE YOUR CONNECTION BELOW THE LINE

  $conn = mysqli_connect("localhost", "root", null, "project01");


  // TOTAL POINTS POSSIBLE: 6

?>
