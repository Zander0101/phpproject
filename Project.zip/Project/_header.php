<!-- Step 1: (5 points) Put your basic opening HTML here -->
<!-- and any logic you require for including style sheets -->
<!-- Ensure you only have from opening <html> to opening <body> here -->
<!-- and not the closing </body> or closing </html> tags -->
<!-- Ensure you HTML is W3C compliant -->
<!-- CREATE YOUR HEADER HTML BELOW THIS LINE -->

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Project 01</title>
  </head>
  <body>



<!-- TOTAL POINTS POSSIBLE: 5 -->
